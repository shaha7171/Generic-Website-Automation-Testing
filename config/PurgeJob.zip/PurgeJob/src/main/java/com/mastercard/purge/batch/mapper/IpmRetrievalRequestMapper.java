package com.mastercard.purge.batch.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mastercard.purge.batch.dto.IpmClearingRetrievalDTO;

public class IpmRetrievalRequestMapper implements RowMapper<IpmClearingRetrievalDTO> {

	@Override
	public IpmClearingRetrievalDTO mapRow(ResultSet resultSet, int rowNum)
			throws SQLException {
		IpmClearingRetrievalDTO ipmClearingRetrievalDTO = new IpmClearingRetrievalDTO();
		
		ipmClearingRetrievalDTO.setClearingId(resultSet.getBigDecimal("clearingId"));
		ipmClearingRetrievalDTO.setClearingDbDttm(resultSet.getString("clearingDbDttm"));
		ipmClearingRetrievalDTO.setPrimaryAccountNumber(resultSet.getString("pan"));
		ipmClearingRetrievalDTO.setAcquirerRefrenceData(resultSet.getString("ard"));
		ipmClearingRetrievalDTO.setRowId(resultSet.getString("ROWID"));
		ipmClearingRetrievalDTO.setRequestId(resultSet.getBigDecimal("requestId"));
		ipmClearingRetrievalDTO.setArcDbDttm(resultSet.getString("arcDbDttm"));
		ipmClearingRetrievalDTO.setIrcDbDttm(resultSet.getString("ircDbDttm"));
		ipmClearingRetrievalDTO.setIrdDbDttm(resultSet.getString("irdDbDttm"));

		return ipmClearingRetrievalDTO;
	}

}
