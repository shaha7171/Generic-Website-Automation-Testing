package com.mastercard.purge.batch;

import java.io.IOException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.BeansException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;


@ComponentScan
@EnableAutoConfiguration
public class Application {
	
	private static final Logger LOGGER = Logger.getLogger(Application.class);

	private static final String RETRIEVAL_REQUEST_PURGE_JOB = "retrievalRequestPurgeJob";
	private static final String CHARGEBACK_PURGE_JOB = "chargeBackPurgeJob";

	public static void main(String[] args) throws BeansException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException, InterruptedException, IOException {
    	
        SpringApplication app = new SpringApplication(Application.class);
        app.setWebEnvironment(false);
        ConfigurableApplicationContext context = app.run(args);
        JobLauncher jobLauncher = context.getBean(JobLauncher.class);
        Job batchJob;
        
        switch(args[0]){
        	case RETRIEVAL_REQUEST_PURGE_JOB:
        		batchJob = context.getBean(RETRIEVAL_REQUEST_PURGE_JOB, Job.class);
        		runJob(jobLauncher, context, batchJob);
        		break;
        	case CHARGEBACK_PURGE_JOB:
        		batchJob = context.getBean(CHARGEBACK_PURGE_JOB, Job.class);
        		runJob(jobLauncher, context, batchJob);
        		break;
        	default:  System.exit(0);
        }
    }
	
	
	private static void runJob(JobLauncher jobLauncher, ConfigurableApplicationContext context, Job batchJob) throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException, InterruptedException{
		
    	JobParameters jobParameters = new JobParametersBuilder()
		.addDate("date", new Date())
		.toJobParameters();  
    	
    	JobExecution jobExecution = jobLauncher.run(batchJob, jobParameters);
    	
    	BatchStatus batchStatus = jobExecution.getStatus();
    	while(batchStatus.isRunning()){
    		LOGGER.info("*********** Still running.... **************");
    		Thread.sleep(1000);
    	}
		ExitStatus exitStatus = jobExecution.getExitStatus();
		String exitCode = exitStatus.getExitCode();
		LOGGER.info(String.format("*********** Exit status: %s", exitCode));


    	JobInstance jobInstance = jobExecution.getJobInstance();
    	LOGGER.info(String.format("********* Name of the job %s", jobInstance.getJobName()));
    	
    	LOGGER.info(String.format("*********** job instance Id: %d", jobInstance.getId()));
    	
    	System.exit(0);
	}
	
	


}