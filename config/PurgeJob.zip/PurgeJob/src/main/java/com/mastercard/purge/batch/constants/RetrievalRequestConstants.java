package com.mastercard.purge.batch.constants;

public class RetrievalRequestConstants {
	
	public static final int REQUESTS_RETENTION = 10;
	public static final String IPM_RETRIEVAL_QUERY = "SELECT CLEARING_ID as clearingId ,TO_CHAR(CLEARING_DB_DTTM,'MM/DD/YY HH24:MI') as clearingDbDttm,D002_PRIMARY_ACCOUNT_NUM as pan,D031_ACQ_REF_DATA as ard,IPM.ROWID,"
														+ " NVL(REQ.REQUEST_ID,-1) as requestId, NVL(TO_CHAR(REQ.ARC_DB_DTTM,'MM/DD/YY HH24:MI') ,'              ') as arcDbDttm,"
														+ "	NVL(TO_CHAR(REQ.IRC_DB_DTTM,'MM/DD/YY HH24:MI'),'              ') as ircDbDttm,"
														+ " NVL(TO_CHAR(REQ.IRD_DB_DTTM,'MM/DD/YY HH24:MI'),'              ')as irdDbDttm"
														+ " FROM IPM_CLEARING_RTRVL IPM, REQUEST REQ  WHERE :retentionDays < SYSDATE - CLEARING_DB_DTTM AND"
														+ "  IPM.CLEARING_ID = REQ.IPM_CLEARING_ID and NOT EXISTS (SELECT CLEARING_ID FROM IPM_CLEARING_CHGBK c where"
														+ " c.CLEARING_ID = ipm.CLEARING_ID)";
	public static final String DELETE_REQUEST_UPLD_SET_QUERY = "DELETE REQUEST_UPLD_SET WHERE DOC_UPLD_SET_ID= :docUploadSetId";
	public static final String DELETE_MERGE_FILE_QUERY = "DELETE MERGED_FILE WHERE DOC_UPLD_SET_ID=:docUploadSetId";
	public static final String DELETE_DOC_UPLD_SET_STATUS_QUERY = "DELETE DOC_UPLD_SET_STATUS WHERE DOC_UPLD_SET_ID=:docUploadSetId";
	public static final String DELETE_DOC_UPLD_FILE_STATUS_QUERY = "DELETE DOC_UPLD_FILE_STATUS where DOC_UPLD_FILE_ID IN (select DOC_UPLD_FILE_ID from DOC_UPLD_FILE where DOC_UPLD_SET_ID=:docUploadSetId)";
	public static final String DELETE_DOC_UPLD_FILE_QUERY = "";//TODO Query to be rewrite 
	public static final String DELETE_DOC_UPLD_SET_QUERY = "DELETE DOC_UPLD_SET WHERE DOC_UPLD_SET_ID=:docUploadSetId;";
	public static final String DELETE_FILE_UPLD_SET_STAT_QUERY = "";//TODO rewrite
	public static final String DELETE_FILE_UPLD_SET_QUERY = "";//TODO rewrite
	public static final String DELETE_NEW_RETRIEVAL_DOCS_QUERY = "DELETE NEW_RETRIEVAL_DOCS WHERE REQUEST_ID = :requestID";
	public static final String DELETE_REQUEST_STAT_QUERY = "DELETE REQUEST_STAT WHERE REQUEST_ID=:requestID";
	public static final String DELETE_REQUEST_QUERY = "DELETE REQUEST WHERE REQUEST_ID = :requestID";
	public static final String DELETE_IPM_CLEARING_RTRVL_QUERY = "DELETE IPM_CLEARING_RTRVL WHERE CLEARING_ID=:clearingId";
	

}
