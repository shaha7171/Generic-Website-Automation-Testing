package com.mastercard.purge.batch.tasklet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.purge.batch.Application;
import com.mastercard.purge.batch.service.RetrievalRequestService;

@Component
public class RetrievalRequestTasklet implements Tasklet {
	
	//private static final Logger LOGGER = Logger.getLogger(RetrievalRequestTasklet.class);
	Log log = LogFactory.getLog(RetrievalRequestTasklet.class);

	@Autowired
	RetrievalRequestService retrievalRequestService;
	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
			
			//LOGGER.info("Purge Starting");
			log.info("Purge Starting");
				
			retrievalRequestService.purgeIPMClearingRtrvl();
		
		 return RepeatStatus.FINISHED;
	}
}