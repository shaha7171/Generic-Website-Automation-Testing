package com.mastercard.purge.batch.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastercard.purge.batch.dao.RetrievalRequestDAO;
import com.mastercard.purge.batch.dto.IpmClearingRetrievalDTO;
import com.mastercard.purge.batch.tasklet.RetrievalRequestTasklet;

@Service
public class RetrievalRequestService {
	
	private static final Logger LOGGER = Logger.getLogger(RetrievalRequestTasklet.class);
	
	@Autowired
	RetrievalRequestDAO retrievalRequestDAO;

	/**
	 * 
	 */
	public void purgeIPMClearingRtrvl() {
		List<IpmClearingRetrievalDTO> ipmClearingRetrievals = retrievalRequestDAO
				.getIpmClearingToPurge();
		LOGGER.info(ipmClearingRetrievals.toString());
		//deleteIpmClearingRetrievalRow(ipmClearingRetrievals);

	}

	/**
	 * @param ipmClearingRetrievals
	 */
	private void deleteIpmClearingRetrievalRow(
			List<IpmClearingRetrievalDTO> ipmClearingRetrievals) {

		// Delete child rows in Requests and Retrieval_Docs
		deleteRequestsRow(ipmClearingRetrievals);
		
		//Delete row from the IPM_Clearing_Rtrvl table
		List<Object[]> clearingIds = new ArrayList<Object[]>();
		for (IpmClearingRetrievalDTO ipm : ipmClearingRetrievals) {
			Object[] tmp = { ipm.getClearingId() };
			clearingIds.add(tmp);
		}
		retrievalRequestDAO.deleteClearingRetrievalTable(clearingIds);
	}

	/**
	 * @param ipmClearingRetrievals
	 */
	private void deleteRequestsRow(List<IpmClearingRetrievalDTO> ipmClearingRetrievals){
		
		// Get the DOC_UPLD_SET_ID value from REQUEST_UPLD_SET for REQUEST_ID, if there is one
		List<BigDecimal> docUploadSetIds = new ArrayList<>();
		if(ipmClearingRetrievals.size()>0){
			docUploadSetIds = retrievalRequestDAO.getDocUploadSetIds();
		}
		
		List<Object[]> requestIds = new ArrayList<Object[]>();
		for (IpmClearingRetrievalDTO ipm : ipmClearingRetrievals) {
			Object[] tmp = { ipm.getRequestId() };
			requestIds.add(tmp);
		}
		
		if(docUploadSetIds.size() >0){
			List<Object[]> inputList = new ArrayList<Object[]>();

			for(BigDecimal ids:docUploadSetIds){
	            Object[] tmp = {ids};
	            inputList.add(tmp);
	        }							
			
			retrievalRequestDAO.deleteRequestUploadSet(inputList);
			
			//Delete image records in PRO tables
			retrievalRequestDAO.deleteImageRecordPro(inputList);
		}
		
		//Delete Rest of the tables associated with ipm clearing retrieval.
		retrievalRequestDAO.deleteRestAssociatedTable(requestIds);
		
	}
}
