package com.mastercard.purge.batch.mapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DocUploadSetMapper implements RowMapper<BigDecimal> {

	@Override
	public BigDecimal mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		
		return resultSet.getBigDecimal("DOC_UPLD_SET_ID");
	}

}
