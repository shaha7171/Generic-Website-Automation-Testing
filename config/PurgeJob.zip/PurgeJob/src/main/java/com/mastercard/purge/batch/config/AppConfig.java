package com.mastercard.purge.batch.config;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.support.ApplicationContextFactory;
import org.springframework.batch.core.configuration.support.GenericApplicationContextFactory;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import com.mastercard.purge.batch.job.RetrievalRequestBatchJob;

@Configuration
@ComponentScan(basePackages="com.mastercard.purge.batch")
@EnableBatchProcessing(modular = true)
public class AppConfig {

	@Bean
	public ApplicationContextFactory addNewPodcastJobs() {
		return new GenericApplicationContextFactory(RetrievalRequestBatchJob.class);
	}

	@Bean(name = "mainDataSource")
	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource mainDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Primary
	@Bean(name = "batchDataSource")
	public DataSource batchDataSource() {
		return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL).setScriptEncoding("UTF-8")
				.addScript("schema-hsqldb.sql").ignoreFailedDrops(true).build();
	}

	@Bean(name = "jdbcMain")
	public JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(mainDataSource());
	}

	@Bean
	public BatchConfigurer configurer(DataSource datasource) {
		return new DefaultBatchConfigurer(batchDataSource());
	}

}
