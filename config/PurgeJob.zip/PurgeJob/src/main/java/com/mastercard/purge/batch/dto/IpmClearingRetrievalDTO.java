package com.mastercard.purge.batch.dto;

import java.math.BigDecimal;

public class IpmClearingRetrievalDTO {

	private BigDecimal clearingId;
	private String clearingDbDttm;
	private String primaryAccountNumber;
	private String acquirerRefrenceData;
	private String rowId;
	private BigDecimal requestId;
	private String arcDbDttm;
	private String ircDbDttm;
	private String irdDbDttm;
	/**
	 * @return the clearingId
	 */
	public BigDecimal getClearingId() {
		return clearingId;
	}
	/**
	 * @param clearingId the clearingId to set
	 */
	public void setClearingId(BigDecimal clearingId) {
		this.clearingId = clearingId;
	}
	/**
	 * @return the clearingDbDttm
	 */
	public String getClearingDbDttm() {
		return clearingDbDttm;
	}
	/**
	 * @param clearingDbDttm the clearingDbDttm to set
	 */
	public void setClearingDbDttm(String clearingDbDttm) {
		this.clearingDbDttm = clearingDbDttm;
	}
	/**
	 * @return the primaryAccountNumber
	 */
	public String getPrimaryAccountNumber() {
		return primaryAccountNumber;
	}
	/**
	 * @param primaryAccountNumber the primaryAccountNumber to set
	 */
	public void setPrimaryAccountNumber(String primaryAccountNumber) {
		this.primaryAccountNumber = primaryAccountNumber;
	}
	/**
	 * @return the acquirerRefrenceData
	 */
	public String getAcquirerRefrenceData() {
		return acquirerRefrenceData;
	}
	/**
	 * @param acquirerRefrenceData the acquirerRefrenceData to set
	 */
	public void setAcquirerRefrenceData(String acquirerRefrenceData) {
		this.acquirerRefrenceData = acquirerRefrenceData;
	}
	/**
	 * @return the rowId
	 */
	public String getRowId() {
		return rowId;
	}
	/**
	 * @param rowId the rowId to set
	 */
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	/**
	 * @return the requestId
	 */
	public BigDecimal getRequestId() {
		return requestId;
	}
	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(BigDecimal requestId) {
		this.requestId = requestId;
	}
	/**
	 * @return the arcDbDttm
	 */
	public String getArcDbDttm() {
		return arcDbDttm;
	}
	/**
	 * @param arcDbDttm the arcDbDttm to set
	 */
	public void setArcDbDttm(String arcDbDttm) {
		this.arcDbDttm = arcDbDttm;
	}
	/**
	 * @return the ircDbDttm
	 */
	public String getIrcDbDttm() {
		return ircDbDttm;
	}
	/**
	 * @param ircDbDttm the ircDbDttm to set
	 */
	public void setIrcDbDttm(String ircDbDttm) {
		this.ircDbDttm = ircDbDttm;
	}
	/**
	 * @return the irdDbDttm
	 */
	public String getIrdDbDttm() {
		return irdDbDttm;
	}
	/**
	 * @param irdDbDttm the irdDbDttm to set
	 */
	public void setIrdDbDttm(String irdDbDttm) {
		this.irdDbDttm = irdDbDttm;
	}
	
	@Override
	public String toString() {
		return "IpmClearingRetrievalDTO [clearingId=" + clearingId + ", clearingDbDttm=" + clearingDbDttm
				+ ", primaryAccountNumber=" + primaryAccountNumber + ", acquirerRefrenceData=" + acquirerRefrenceData
				+ ", rowId=" + rowId + ", requestId=" + requestId + ", arcDbDttm=" + arcDbDttm + ", ircDbDttm="
				+ ircDbDttm + ", irdDbDttm=" + irdDbDttm + "]";
	}
	
}
