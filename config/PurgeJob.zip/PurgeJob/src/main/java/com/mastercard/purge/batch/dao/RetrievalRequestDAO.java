package com.mastercard.purge.batch.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mastercard.purge.batch.constants.RetrievalRequestConstants;
import com.mastercard.purge.batch.dto.IpmClearingRetrievalDTO;
import com.mastercard.purge.batch.mapper.DocUploadSetMapper;
import com.mastercard.purge.batch.mapper.IpmRetrievalRequestMapper;

@Repository
public class RetrievalRequestDAO {

	private JdbcTemplate jdbcTemplateObject;
	
	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	    this.jdbcTemplateObject = jdbcTemplate;
	}

	/**
	 * @return
	 */
	public List<IpmClearingRetrievalDTO> getIpmClearingToPurge() {
		
		int retentionDays = RetrievalRequestConstants.REQUESTS_RETENTION;
		List<IpmClearingRetrievalDTO> ipmClearingRetrieval = jdbcTemplateObject.query(
				RetrievalRequestConstants.IPM_RETRIEVAL_QUERY, new IpmRetrievalRequestMapper(),retentionDays);

		return ipmClearingRetrieval;

	}

	/**
	 * @return
	 */
	public List<BigDecimal> getDocUploadSetIds() {
		List<BigDecimal> docUploadSetIds = jdbcTemplateObject.query(RetrievalRequestConstants.IPM_RETRIEVAL_QUERY,
				new DocUploadSetMapper());
		return docUploadSetIds;
	}

	/**
	 * @param inputList
	 */
	public void deleteRequestUploadSet(List<Object[]> inputList) {

		// Delete row from the REQUEST_UPLD_SET table.
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_REQUEST_UPLD_SET_QUERY, inputList);
	}

	/**
	 * @param docUploadSetIds
	 */
	public void deleteImageRecordPro(List<Object[]> docUploadSetIds) {

		// Delete row from the MERGED_FILE table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_MERGE_FILE_QUERY, docUploadSetIds);

		// Delete row from the DOC_UPLD_SET_STATUS table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_DOC_UPLD_SET_STATUS_QUERY, docUploadSetIds);

		// Delete row from the DOC_UPLD_FILE_STATUS table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_DOC_UPLD_FILE_STATUS_QUERY, docUploadSetIds);

		// Delete row from the DOC_UPLD_FILE table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_DOC_UPLD_FILE_QUERY, docUploadSetIds);

		// Delete row from the DOC_UPLD_SET table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_DOC_UPLD_SET_QUERY, docUploadSetIds);

		// Delete row from the FILE_UPLD_SET_STAT table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_FILE_UPLD_SET_STAT_QUERY, docUploadSetIds);

		// Delete row from the FILE_UPLD_SET table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_FILE_UPLD_SET_QUERY, docUploadSetIds);

	}

	/**
	 * @param requestIds
	 */
	public void deleteRestAssociatedTable(List<Object[]> requestIds) {
		// Delete the image from the NEW_RETRIEVAL_DOCS, if there is one
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_NEW_RETRIEVAL_DOCS_QUERY, requestIds);

		// Delete row from the REQUEST_STAT table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_REQUEST_STAT_QUERY, requestIds);

		// Delete the row from the Requests table
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_REQUEST_QUERY, requestIds);
	}

	/**
	 * @param clearingIds
	 */
	public void deleteClearingRetrievalTable(List<Object[]> clearingIds) {
		jdbcTemplateObject.batchUpdate(RetrievalRequestConstants.DELETE_IPM_CLEARING_RTRVL_QUERY, clearingIds);
	}

}
